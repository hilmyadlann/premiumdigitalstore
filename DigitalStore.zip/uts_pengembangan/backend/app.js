const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(helmet());
app.use(express.json());

let items = [
  { id: uuidv4(), name: 'Akun Netflix Premium', category: 'Netflix', price: 50000 },
  { id: uuidv4(), name: 'Akun YouTube Premium', category: 'YouTube', price: 60000 },
  { id: uuidv4(), name: 'Akun Spotify Premium', category: 'Spotify', price: 45000 },
];

// Get all items
app.get('/api/items', (req, res) => {
  res.json(items);
});

// Add a new item with validation
app.post('/api/items', [
  body('name').notEmpty().withMessage('Name is required'),
  body('category').notEmpty().withMessage('Category is required'),
  body('price').isInt({ gt: 0 }).withMessage('Price must be a positive integer')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const newItem = { id: uuidv4(), ...req.body };
  items.push(newItem);
  res.status(201).json(newItem);
});

// Update an item with validation
app.put('/api/items/:id', [
  body('name').optional().notEmpty().withMessage('Name must not be empty'),
  body('category').optional().notEmpty().withMessage('Category must not be empty'),
  body('price').optional().isInt({ gt: 0 }).withMessage('Price must be a positive integer')
], (req, res) => {
  const { id } = req.params;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const index = items.findIndex(item => item.id === id);
  if (index !== -1) {
    items[index] = { ...items[index], ...req.body };
    res.json(items[index]);
  } else {
    res.status(404).json({ message: 'Item not found' });
  }
});

// Delete an item
app.delete('/api/items/:id', (req, res) => {
  const { id } = req.params;
  const index = items.findIndex(item => item.id === id);

  if (index !== -1) {
    const deletedItem = items.splice(index, 1);
    res.json(deletedItem[0]);
  } else {
    res.status(404).json({ message: 'Item not found' });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
