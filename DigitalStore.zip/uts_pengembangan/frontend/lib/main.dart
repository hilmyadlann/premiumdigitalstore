import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UTS PENGEMBANGAN APLIKASI',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<dynamic> items = [];

  @override
  void initState() {
    super.initState();
    fetchItems();
  }

  Future<void> fetchItems() async {
    final response = await http.get(Uri.parse('http://localhost:3000/api/items'));
    if (response.statusCode == 200) {
      setState(() {
        items = json.decode(response.body);
      });
    } else {
      throw Exception('Failed to load items');
    }
  }

  Future<void> addItem(String name, String category, int price) async {
    final response = await http.post(
      Uri.parse('http://localhost:3000/api/items'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'name': name, 'category': category, 'price': price}),
    );
    if (response.statusCode == 201) {
      fetchItems();
    } else {
      throw Exception('Failed to add item');
    }
  }

  Future<void> editItem(int id, String name, String category, int price) async {
    final response = await http.put(
      Uri.parse('http://localhost:3000/api/items/$id'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'name': name, 'category': category, 'price': price}),
    );
    if (response.statusCode == 200) {
      fetchItems();
    } else {
      throw Exception('Failed to edit item');
    }
  }

  Future<void> deleteItem(int id) async {
    final response = await http.delete(Uri.parse('http://localhost:3000/api/items/$id'));
    if (response.statusCode == 200) {
      fetchItems();
    } else {
      throw Exception('Failed to delete item');
    }
  }

  void showItemForm({int? id, String? name, String? category, int? price}) {
    final TextEditingController nameController = TextEditingController(text: name);
    final TextEditingController categoryController = TextEditingController(text: category);
    final TextEditingController priceController = TextEditingController(text: price?.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(id == null ? 'Tambah Barang' : 'Edit Barang'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Nama Barang'),
              ),
              TextField(
                controller: categoryController,
                decoration: InputDecoration(labelText: 'Kategori Barang'),
              ),
              TextField(
                controller: priceController,
                decoration: InputDecoration(labelText: 'Harga Barang'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                final String name = nameController.text;
                final String category = categoryController.text;
                final int price = int.parse(priceController.text);

                if (id == null) {
                  addItem(name, category, price);
                } else {
                  editItem(id, name, category, price);
                }
                Navigator.pop(context);
              },
              child: Text(id == null ? 'Tambah' : 'Simpan'),
            ),
          ],
        );
      },
    );
  }

  void confirmDelete(int id) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Hapus Barang'),
          content: Text('Apakah Anda yakin ingin menghapus barang ini?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                deleteItem(id);
                Navigator.pop(context);
              },
              child: Text('Hapus'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, // Ganti dari 'primary' ke 'backgroundColor'
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'UTS PENGEMBANGAN APLIKASI',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurpleAccent,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.purple[300]!, Colors.deepPurpleAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                "Daftar Barang Digital",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  return Card(
                    color: Colors.white.withOpacity(0.8),
                    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: ListTile(
                      title: Text(
                        item['name'],
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple,
                        ),
                      ),
                      subtitle: Text(
                        '${item['category']} - Rp${item['price']}',
                        style: TextStyle(color: Colors.grey[700]),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.blue),
                            onPressed: () {
                              showItemForm(
                                id: item['id'],
                                name: item['name'],
                                category: item['category'],
                                price: item['price'],
                              );
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              confirmDelete(item['id']);
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: () {
                  showItemForm();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple, // Ganti dari 'primary' ke 'backgroundColor'
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: Text(
                  'Tambah Barang',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
