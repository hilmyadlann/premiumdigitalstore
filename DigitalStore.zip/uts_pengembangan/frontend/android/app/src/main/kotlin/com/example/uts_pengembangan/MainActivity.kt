package com.example.uts_pengembangan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
